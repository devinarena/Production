create unique index EMPLOYEE_ID_UINDEX
    on EMPLOYEE (ID);

